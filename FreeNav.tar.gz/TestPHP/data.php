<?php 
class Data {
    var $id;  
    var $level1;
    var $level2;
    var $level3;
    var $name;
    var $URL;
    var $content;
}
?>